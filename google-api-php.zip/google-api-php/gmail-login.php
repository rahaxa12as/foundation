<?php
session_start();
require_once 'google-api-php-client/vendor/autoload.php'; // adjust path if needed

// === Configuration ===
$clientID = '207266525565-2f0p5evq7qg5ir2dlf5s4erkukhvmv9p.apps.googleusercontent.com';
$clientSecret = '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';
$redirectUri = 'axatech.io'; // change as needed

// === Setup Google Client ===
$client = new Google_Client();
$client->setClientId($clientID);
$client->setClientSecret($clientSecret);
$client->setRedirectUri($redirectUri);
$client->addScope("email");
$client->addScope("profile");

if (isset($_GET['code'])) {
    // Authenticate user
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $client->setAccessToken($token);

    // Get user info
    $oauth2 = new Google_Service_Oauth2($client);
    $userinfo = $oauth2->userinfo->get();

    $_SESSION['user_name'] = $userinfo->name;
    $_SESSION['user_email'] = $userinfo->email;

    header('Location: gmail-login.php');
    exit();
}

// === Logout ===
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: gmail-login.php');
    exit();
}

// === UI ===
if (!isset($_SESSION['user_email'])) {
    $loginUrl = $client->createAuthUrl();
    echo "<a href='$loginUrl'>Login with Gmail</a>";
} else {
    echo "<h3>Welcome, {$_SESSION['user_name']}</h3>";
    echo "<p>Email: {$_SESSION['user_email']}</p>";
    echo "<a href='?logout'>Logout</a>";
}
